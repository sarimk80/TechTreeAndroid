package com.example.techtreeandroid._mainActivity;

public interface Event {

    void Sign_in();
}
