package com.example.techtreeandroid._mainActivity;

import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.example.techtreeandroid.R;
import com.example.techtreeandroid.databinding.ActivityMainBinding;

import es.dmoral.toasty.Toasty;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding activityMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        activityMainBinding= DataBindingUtil.setContentView(this,R.layout.activity_main);

        activityMainBinding.setEvent(new Event() {
            @Override
            public void Sign_in() {
                Toasty.success(getApplicationContext(),"Working", Toast.LENGTH_LONG).show();
            }
        });
    }



}
